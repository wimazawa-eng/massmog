
export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{margin:0,fontFamily:"Arial",background:"#0b0b0f",color:"white"}}>
        {children}
      </body>
    </html>
  )
}
