
export default function Leaderboard() {
  const mock = [
    {name:"User1",score:92},
    {name:"User2",score:88},
    {name:"User3",score:81}
  ]

  return (
    <main style={{padding:40}}>
      <h2>Leaderboard</h2>
      {mock.map((u,i)=>(
        <div key={i} style={{margin:10,padding:10,border:"1px solid white"}}>
          {u.name} - {u.score}
        </div>
      ))}
    </main>
  )
}
