
'use client'
import { useState } from 'react'

export default function Upload() {
  const [file,setFile] = useState(null)
  const [result,setResult] = useState(null)

  async function submit() {
    const fd = new FormData()
    fd.append('image',file)
    const res = await fetch('/api/analyze',{method:'POST',body:fd})
    const data = await res.json()
    setResult(data)
  }

  return (
    <main style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",gap:20}}>
      <h2>Live Capture</h2>
      <input type="file" accept="image/*" capture="user" onChange={(e)=>setFile(e.target.files[0])}/>
      <button onClick={submit} style={{padding:10}}>Analyze</button>
      {result && (
        <div>
          <h3>Score {result.score}</h3>
          <p>{result.rank}</p>
        </div>
      )}
    </main>
  )
}
