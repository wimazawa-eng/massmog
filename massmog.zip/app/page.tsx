
export default function Home() {
  return (
    <main style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",gap:20}}>
      <h1>Massmog</h1>
      <a href="/upload" style={{padding:12,background:"white",color:"black",textDecoration:"none"}}>Get Rated</a>
      <a href="/leaderboard" style={{color:"white"}}>Leaderboard</a>
    </main>
  )
}
