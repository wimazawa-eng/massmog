
export async function POST(req) {
  const form = await req.formData()
  const img = form.get('image')

  const score = Math.floor(60 + Math.random()*35)

  let rank = 'Beginner'
  if(score>85) rank='Mass Monster'
  else if(score>75) rank='Shredded'
  else if(score>65) rank='Gym Regular'

  return Response.json({score,rank})
}
